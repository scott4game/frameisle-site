# Reproducible LGPL baseline build

Requirements: Xcode with macOS/iOS/tvOS SDKs, Python 3, CMake 4.2.3.
Run `scripts/ffmpeg/bootstrap.sh`, then `scripts/build-ffmpeg.sh --target all`.
Only checksum-pinned upstream archives from `Vendor/FFmpeg/manifest.json` are used.
No binary FFmpeg distribution or host-installed codec library is accepted.

Eight architecture/platform slices produce ten dynamic XCFrameworks. macOS uses
versioned frameworks; iOS/tvOS use flat frameworks. Dependencies point to sibling
`@rpath/name.framework/name` paths; there are no nested frameworks. Compiled
binaries and build directories are ignored by Git. Preserve all per-slice
`configure-command.json` and `binary-manifest.json` files with release evidence.

Run `python3 scripts/ffmpeg/audit.py --ios-simulator <UDID> --tvos-simulator <UDID>`.
This verifies linked dependencies and hashes every slice, compiles a probe for
every slice, and executes probes on both Mac architectures and supplied arm64
simulators. Physical-device probes remain a separate requirement. Simulator
x86_64 probes are compiled but not executed on an Apple Silicon host.

The probe enumerates the complete registered codec set; all must be decoders
on the exact allowlist. No protocols, encoders, H.264/HEVC/AAC/AC3/EAC3/ALAC,
DTS/TrueHD/VC-1/WMV/MPEG-4 Part 2 or wrapper decoders are permitted. Build tests
repeat the registry audit inside the matching application runtime.

M1 only embeds the libraries and exposes the bridge/probe; the factory still
creates AVPlaybackEngine. Broader file routing must not be enabled until the
actual decoder pipeline passes its fixture matrix. Source/relink distribution,
security closure, patent review and physical-device acceptance remain gates.

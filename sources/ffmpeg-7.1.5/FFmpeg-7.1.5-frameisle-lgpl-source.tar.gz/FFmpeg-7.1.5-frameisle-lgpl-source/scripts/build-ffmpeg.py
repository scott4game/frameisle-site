#!/usr/bin/env python3
"""Pinned, source-only Apple framework build. Never falls back to host codec libs."""
import argparse, hashlib, json, os, plistlib, shutil, subprocess, tarfile
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
SANITIZERS=os.environ.get('FRAMEISLE_SANITIZERS','')
BUILD = ROOT/('build/ffmpeg-asan' if SANITIZERS else 'build/ffmpeg'); SOURCES = ROOT/'build/sources'; VENDOR = ROOT/'Vendor/FFmpeg'
LOCK = json.loads((VENDOR/'manifest.json').read_text())
JOBS = os.environ.get('FRAMEISLE_BUILD_JOBS','4')
TOOLS = BUILD/'tools'
PYTOOLS = ROOT/'build/tools-env/bin'
TARGETS = {
 'macos-arm64':('macosx','arm64','arm64-apple-macos14.0'),
 'macos-x86_64':('macosx','x86_64','x86_64-apple-macos14.0'),
 'ios-arm64':('iphoneos','arm64','arm64-apple-ios17.0'),
 'ios-sim-arm64':('iphonesimulator','arm64','arm64-apple-ios17.0-simulator'),
 'ios-sim-x86_64':('iphonesimulator','x86_64','x86_64-apple-ios17.0-simulator'),
 'tvos-arm64':('appletvos','arm64','arm64-apple-tvos17.0'),
 'tvos-sim-arm64':('appletvsimulator','arm64','arm64-apple-tvos17.0-simulator'),
 'tvos-sim-x86_64':('appletvsimulator','x86_64','x86_64-apple-tvos17.0-simulator'),
}
LIBS = ['avcodec','avformat','avutil','swresample','swscale','dav1d','ass','freetype','harfbuzz','fribidi']
DECODERS = 'vp8,vp9,libdav1d,opus,vorbis,flac,mp3,mp3float,pcm_s16le,pcm_s16be,pcm_s24le,pcm_s24be,pcm_s32le,pcm_s32be,pcm_u8,pcm_s8,pcm_f32le,pcm_f64le,mpeg2video,mpeg1video,subrip,ass,ssa,webvtt,movtext,pgssub,dvdsub,dvbsub'
DEMUXERS = 'matroska,mov,avi,mpegts,ogg,flv,wav,srt,ass,webvtt'
PARSERS = 'h264,hevc,aac,ac3,opus,vorbis,flac,mpegaudio,mpegvideo,vp8,vp9,av1'
BSFS = 'extract_extradata,h264_mp4toannexb,hevc_mp4toannexb,aac_adtstoasc'
def run(args, cwd=None, env=None):
    print('+ '+' '.join(map(str,args)),flush=True)
    subprocess.run(list(map(str,args)),cwd=cwd or ROOT,env=env,check=True)
def output(args): return subprocess.check_output(args,text=True).strip()
def source(name):
    item=LOCK['sources'][name]; tar=SOURCES/item['url'].rsplit('/',1)[1]
    if not tar.exists(): run(['curl','-fL','--retry','2','--connect-timeout','20',item['url'],'-o',tar])
    assert hashlib.sha256(tar.read_bytes()).hexdigest()==item['sha256'], 'Source checksum mismatch: '+name
    with tarfile.open(tar) as archive:
        folder=SOURCES/archive.getmembers()[0].name.split('/')[0]
        if not folder.exists(): archive.extractall(SOURCES)
    return folder

def host_tools():
    TOOLS.mkdir(parents=True,exist_ok=True)
    for name,exe,flags in [('pkgconf','pkg-config',['--disable-shared','--with-pkg-config-dir=']),('nasm','nasm',[])]:
        if (TOOLS/'bin'/exe).exists(): continue
        src=source(name); work=BUILD/('tool-'+name);work.mkdir(parents=True,exist_ok=True)
        run([src/'configure','--prefix='+str(TOOLS),*flags],cwd=work)
        run(['make','-j'+JOBS],cwd=work);run(['make','install'],cwd=work)
        if name=='pkgconf' and not (TOOLS/'bin/pkg-config').exists(): (TOOLS/'bin/pkg-config').symlink_to('pkgconf')

def build_target(target):
    sdk,arch,triple=TARGETS[target]; out=BUILD/target; prefix=out/'prefix'; prefix.mkdir(parents=True,exist_ok=True)
    sdkroot=output(['xcrun','--sdk',sdk,'--show-sdk-path']);cc=output(['xcrun','--sdk',sdk,'--find','clang']);cxx=output(['xcrun','--sdk',sdk,'--find','clang++'])
    flags=['-target',triple,'-isysroot',sdkroot,'-O2','-fPIC']
    if SANITIZERS:flags += ['-fsanitize='+SANITIZERS,'-fno-omit-frame-pointer']
    env=dict(os.environ,PATH=str(TOOLS/'bin')+':'+str(PYTOOLS)+':/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin',PKG_CONFIG_LIBDIR=str(prefix/'lib/pkgconfig'),PKG_CONFIG_PATH=str(prefix/'lib/pkgconfig'))
    cross=out/'cross.ini'
    cross.write_text("[binaries]\nc = "+repr(cc)+"\ncpp = "+repr(cxx)+"\nobjc = "+repr(cc)+"\nobjcpp = "+repr(cxx)+"\nar = '/usr/bin/ar'\nstrip = '/usr/bin/strip'\npkg-config = "+repr(str(TOOLS/'bin/pkg-config'))+"\nnasm = "+repr(str(TOOLS/'bin/nasm'))+"\n[host_machine]\nsystem = 'darwin'\ncpu_family = "+repr('aarch64' if arch=='arm64' else 'x86_64')+"\ncpu = "+repr(arch)+"\nendian = 'little'\n[properties]\nneeds_exe_wrapper = true\n[built-in options]\nc_args = "+repr(flags)+"\ncpp_args = "+repr(flags)+"\nobjc_args = "+repr(flags)+"\nobjcpp_args = "+repr(flags)+"\nc_link_args = "+repr(flags+['-Wl,-headerpad_max_install_names'])+"\ncpp_link_args = "+repr(flags+['-Wl,-headerpad_max_install_names'])+'\n')
    def meson(name, options):
        work=out/name
        if (work/'.installed').exists(): return
        src=source(name)
        if not (work/'build.ninja').exists():run([PYTOOLS/'meson','setup',work,src,'--prefix',prefix,'--libdir','lib','--default-library','shared','--buildtype','release','--cross-file',cross,'--wrap-mode','nodownload',*options],env=env)
        run([PYTOOLS/'ninja','-C',work,'-j',JOBS],env=env);run([PYTOOLS/'ninja','-C',work,'install'],env=env);(work/'.installed').touch()
    meson('dav1d',['-Denable_tools=false','-Denable_tests=false','-Denable_examples=false','-Denable_docs=false'])
    work=out/'freetype'
    if not (work/'.installed').exists():
        run(['/usr/local/bin/cmake','-S',source('freetype'),'-B',work,'-G','Ninja','-DCMAKE_MAKE_PROGRAM='+str(PYTOOLS/'ninja'),'-DCMAKE_BUILD_TYPE=Release','-DCMAKE_INSTALL_PREFIX='+str(prefix),'-DCMAKE_C_COMPILER='+cc,'-DCMAKE_SYSTEM_NAME='+('Darwin' if sdk=='macosx' else 'tvOS' if sdk.startswith('appletv') else 'iOS'),'-DCMAKE_OSX_SYSROOT='+sdkroot,'-DCMAKE_OSX_ARCHITECTURES='+arch,'-DCMAKE_OSX_DEPLOYMENT_TARGET='+('14.0' if sdk=='macosx' else '17.0'),'-DCMAKE_C_FLAGS='+' '.join(flags),'-DCMAKE_SHARED_LINKER_FLAGS=-Wl,-headerpad_max_install_names','-DBUILD_SHARED_LIBS=ON','-DFT_DISABLE_ZLIB=ON','-DFT_DISABLE_BZIP2=ON','-DFT_DISABLE_PNG=ON','-DFT_DISABLE_HARFBUZZ=ON','-DFT_DISABLE_BROTLI=ON'],env=env)
        run(['/usr/local/bin/cmake','--build',work,'-j',JOBS],env=env);run(['/usr/local/bin/cmake','--install',work],env=env);(work/'.installed').touch()
    meson('harfbuzz',['-Dglib=disabled','-Dgobject=disabled','-Dcairo=disabled','-Dicu=disabled','-Dfreetype=enabled','-Dcoretext=enabled','-Dtests=disabled','-Ddocs=disabled','-Dutilities=disabled'])
    meson('fribidi',['-Ddocs=false','-Dbin=false','-Dtests=false'])
    meson('libass',['-Dtest=disabled','-Dcompare=disabled','-Dprofile=disabled','-Dfuzz=disabled','-Dcheckasm=disabled','-Dfontconfig=disabled','-Ddirectwrite=disabled','-Dcoretext=enabled','-Dlibunibreak=disabled'])
    work=out/'ffmpeg';work.mkdir(exist_ok=True)
    args=[str(source('ffmpeg')/'configure'),'--prefix='+str(prefix),'--arch='+('aarch64' if arch=='arm64' else arch),'--target-os=darwin','--enable-cross-compile','--cc='+cc,'--cxx='+cxx,'--pkg-config='+str(TOOLS/'bin/pkg-config'),'--extra-cflags='+' '.join(flags),'--extra-ldflags='+' '.join(flags+['-Wl,-headerpad_max_install_names']),'--enable-shared','--disable-static','--enable-pic','--disable-gpl','--disable-nonfree','--disable-autodetect','--disable-programs','--disable-doc','--disable-debug','--disable-avdevice','--disable-avfilter','--disable-postproc','--disable-network','--disable-everything','--disable-audiotoolbox','--disable-videotoolbox','--enable-libdav1d','--enable-avformat','--enable-avcodec','--enable-swscale','--enable-swresample','--enable-demuxer='+DEMUXERS,'--enable-decoder='+DECODERS,'--enable-parser='+PARSERS,'--enable-bsf='+BSFS]
    saved=out/'configure-command.json'
    if not (work/'.installed').exists() or not saved.exists() or json.loads(saved.read_text()) != args:
        (out/'configure-command.json').write_text(json.dumps(args,indent=2)+'\n')
        run(args,cwd=work,env=env);run(['make','-j'+JOBS],cwd=work,env=env);run(['make','install'],cwd=work,env=env);(work/'.installed').touch()
    package_target(target,prefix)

def package_target(target,prefix):
    frameworks=BUILD/target/'frameworks';frameworks.mkdir(exist_ok=True)
    paths={}
    for name in LIBS:
        matches=[p for p in (prefix/'lib').glob('lib'+name+'.*.dylib') if not p.is_symlink()]
        assert len(matches)==1,(name,matches)
        paths[name]=matches[0]
    for name,binary in paths.items():
        folder=frameworks/(name+'.framework')
        if folder.exists():shutil.rmtree(folder)
        folder.mkdir()
        shutil.copy2(binary,folder/name)
        run(['install_name_tool','-id','@rpath/'+name+'.framework/'+name,folder/name])
        links=output(['otool','-L',str(folder/name)]).splitlines()[2:]
        for line in links:
            old=line.strip().split(' (')[0]
            for dependency in LIBS:
                if Path(old).name.startswith('lib'+dependency+'.'):
                    run(['install_name_tool','-change',old,'@rpath/'+dependency+'.framework/'+dependency,folder/name])
        info={'CFBundleIdentifier':'com.frameisle.media.'+name,'CFBundleName':name,'CFBundleExecutable':name,'CFBundlePackageType':'FMWK','CFBundleShortVersionString':'1.0.0','CFBundleVersion':'1','MinimumOSVersion':'14.0' if target.startswith('macos') else '17.0'}
        (folder/'Info.plist').write_bytes(plistlib.dumps(info))
        headers=folder/'Headers'
        if headers.exists():shutil.rmtree(headers)
        shutil.copytree(prefix/'include',headers)
        if target.startswith('macos'):
            version=folder/'Versions/A';version.mkdir(parents=True);(version/'Resources').mkdir()
            (folder/name).rename(version/name);(folder/'Info.plist').rename(version/'Resources/Info.plist');headers.rename(version/'Headers')
            (folder/'Versions/Current').symlink_to('A');(folder/name).symlink_to('Versions/Current/'+name);(folder/'Headers').symlink_to('Versions/Current/Headers');(folder/'Resources').symlink_to('Versions/Current/Resources')
        run(['codesign','--force','--sign','-',folder])
    (BUILD/target/'binary-manifest.json').write_text(json.dumps({n:hashlib.sha256((frameworks/(n+'.framework')/n).read_bytes()).hexdigest() for n in LIBS},indent=2)+'\n')

def xcframeworks():
    groups=[('macos',['macos-arm64','macos-x86_64']),('ios',['ios-arm64']),('ios-simulator',['ios-sim-arm64','ios-sim-x86_64']),('tvos',['tvos-arm64']),('tvos-simulator',['tvos-sim-arm64','tvos-sim-x86_64'])]
    for name in LIBS:
        args=['xcodebuild','-create-xcframework']
        for group,targets in groups:
            source=BUILD/targets[0]/'frameworks'/(name+'.framework');out=BUILD/'universal'/group/source.name
            if out.exists():shutil.rmtree(out)
            out.parent.mkdir(parents=True,exist_ok=True);shutil.copytree(source,out,symlinks=True)
            if len(targets)>1:run(['lipo','-create',*[BUILD/t/'frameworks'/(name+'.framework')/name for t in targets],'-output',(out/name).resolve()])
            run(['codesign','--force','--sign','-',out])
            args+=['-framework',out]
        dest=VENDOR/(name+'.xcframework')
        if dest.exists():shutil.rmtree(dest)
        run(args+['-output',dest])
    shutil.copytree(BUILD/'macos-arm64/prefix/include',VENDOR/'include',dirs_exist_ok=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--target',choices=list(TARGETS)+['all'],default='all');parser.add_argument('--package-only',action='store_true');args=parser.parse_args()
    BUILD.mkdir(parents=True,exist_ok=True);SOURCES.mkdir(parents=True,exist_ok=True)
    if LOCK.get('licensedCodecsEnabled'):raise SystemExit('Licensed-codec profile is not authorized for this build')
    if SANITIZERS and args.target != 'macos-arm64':raise SystemExit('Sanitizer profile is isolated to macos-arm64 and never packaged for release')
    if not args.package_only:
        host_tools()
        for target in TARGETS if args.target=='all' else [args.target]:build_target(target)
    if (args.target=='all' or args.package_only) and not SANITIZERS:xcframeworks()

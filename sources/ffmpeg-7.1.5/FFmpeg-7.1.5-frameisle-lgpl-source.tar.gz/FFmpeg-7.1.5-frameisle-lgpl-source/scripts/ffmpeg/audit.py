#!/usr/bin/env python3
"""Audit every built slice and execute probes only on matching runtimes."""
import argparse,hashlib,json,subprocess,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import importlib.util
spec=importlib.util.spec_from_file_location('builder',Path(__file__).resolve().parents[1]/'build-ffmpeg.py');b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
def run(args):return subprocess.check_output(list(map(str,args)),text=True)
p=argparse.ArgumentParser();p.add_argument('--ios-simulator');p.add_argument('--tvos-simulator');a=p.parse_args()
report={'slices':{},'deviceRuntimeProbe':'pending physical iOS/tvOS devices'}
for target,(sdk,arch,triple) in b.TARGETS.items():
 base=b.BUILD/target;fw=base/'frameworks';config=json.loads((base/'configure-command.json').read_text())
 assert '--disable-gpl' in config and '--disable-nonfree' in config and '--disable-network' in config
 assert not any(x in config for x in ['--enable-gpl','--enable-nonfree'])
 checks={}
 for name in b.LIBS:
  binary=fw/(name+'.framework')/name;links=run(['otool','-L',binary]);symbols=run(['nm','-gU',binary])
  assert 'vlc' not in links.lower() and 'libvlc_' not in symbols
  for line in links.splitlines()[2:]:
   path=line.strip().split(' (')[0]
   assert path.startswith(('/System/Library/','/usr/lib/')) or path.startswith('@rpath/') and path.split('/')[1] in [n+'.framework' for n in b.LIBS],(target,name,path)
  checks[name]=hashlib.sha256(binary.read_bytes()).hexdigest()
 out=b.BUILD/('probe-'+target)
 subprocess.run(['xcrun','--sdk',sdk,'clang','-target',triple,'-isysroot',run(['xcrun','--sdk',sdk,'--show-sdk-path']).strip(),str(b.ROOT/'scripts/ffmpeg/probe.c'),'-I',str(base/'prefix/include'),'-F',str(fw),'-framework','avcodec','-framework','avformat','-framework','avutil','-Wl,-rpath,'+str(fw),'-o',str(out)],check=True)
 subprocess.run(['codesign','--force','--sign','-',str(out)],check=True,stdout=subprocess.DEVNULL)
 result={'sha256':checks,'probe':'compiled; execution requires matching platform'}
 command=None
 if sdk=='macosx':command=['arch','-'+arch,out]
 elif arch=='arm64' and sdk=='iphonesimulator' and a.ios_simulator:command=['xcrun','simctl','spawn',a.ios_simulator,out]
 elif arch=='arm64' and sdk=='appletvsimulator' and a.tvos_simulator:command=['xcrun','simctl','spawn',a.tvos_simulator,out]
 if command:
  result['probe']=json.loads(run(command));assert 'mov_text' in result['probe']['decoders']
 report['slices'][target]=result
path=b.BUILD/'audit.json';path.write_text(json.dumps(report,indent=2)+'\n');print(path)

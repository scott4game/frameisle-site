#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../.."
python3 -m venv build/tools-env
build/tools-env/bin/python -m pip install -r scripts/ffmpeg/build-tools.txt
command -v cmake >/dev/null || { echo 'Install CMake 4.2.3 before building.' >&2; exit 1; }

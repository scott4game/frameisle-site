#include <stdio.h>
#include <string.h>
#include <libavcodec/avcodec.h>
#include <libavformat/avformat.h>
static const char *allowed = ",vp8,vp9,libdav1d,opus,vorbis,flac,mp3,mp3float,pcm_s16le,pcm_s16be,pcm_s24le,pcm_s24be,pcm_s32le,pcm_s32be,pcm_u8,pcm_s8,pcm_f32le,pcm_f64le,mpeg2video,mpeg1video,subrip,ass,ssa,webvtt,mov_text,pgssub,dvdsub,dvbsub,";
int main(void) {
    const char *configuration = avcodec_configuration();
    if (!strstr(avcodec_license(), "LGPL") || strstr(configuration, "--enable-gpl") || strstr(configuration, "--enable-nonfree")) return 10;
    enum AVCodecID denied[] = {AV_CODEC_ID_H264,AV_CODEC_ID_HEVC,AV_CODEC_ID_AAC,AV_CODEC_ID_AC3,AV_CODEC_ID_EAC3,AV_CODEC_ID_ALAC,AV_CODEC_ID_DTS,AV_CODEC_ID_TRUEHD,AV_CODEC_ID_VC1,AV_CODEC_ID_WMV1,AV_CODEC_ID_WMV2,AV_CODEC_ID_WMV3,AV_CODEC_ID_MPEG4};
    for (unsigned i=0;i<sizeof(denied)/sizeof(*denied);i++) if (avcodec_find_decoder(denied[i])) return 11;
    void *protocol = NULL; if (avio_enum_protocols(&protocol,0)) return 15;
    void *iterator = NULL; const AVCodec *codec; int count=0;
    printf("{\"license\":\"%s\",\"decoders\":[", avcodec_license());
    while ((codec = av_codec_iterate(&iterator))) {
        if (!av_codec_is_decoder(codec)) return 12; // no encoders in the baseline
        char token[128];snprintf(token,sizeof(token),",%s,",codec->name);
        if (!strstr(allowed,token)) return 13;
        printf("%s\"%s\"",count++?",":"",codec->name);
    }
    printf("],\"forbiddenDecoderCheck\":true,\"networkEnabled\":false}\n");
    return count ? 0 : 14;
}

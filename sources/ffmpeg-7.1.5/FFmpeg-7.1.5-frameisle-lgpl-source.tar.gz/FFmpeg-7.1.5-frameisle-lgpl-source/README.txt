Exact upstream archives for the FrameIsle LGPL baseline.
Extract each upstream archive under build/sources or allow the checksum-verified build script to download the same archive.
Use the included bootstrap/build instructions. Dependencies are dynamic; proprietary app sources are not required to rebuild these libraries.
No keys, certificates, NAS credentials, user media or application binaries are included.
